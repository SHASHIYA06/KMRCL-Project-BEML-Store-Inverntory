export function getProducts() {
  return JSON.parse(localStorage.getItem("products")) || []
}

export function updateProducts(products) {
  localStorage.setItem("products", JSON.stringify(products))
}

export function displayAlert() {
  var products = getProducts()
  products.forEach((product) => {
    if (product.quantity < product.minLimit) {
      alert(`Low stock alert for ${product.name}! ${product.minLimit} or fewer items remaining for restocking.`)
    }
  })
}

