"use client"

import { useState } from "react"

interface AddItemModalProps {
  isOpen: boolean
  onClose: () => void
  onAddItem: (item: any) => void
}

export default function AddItemModal({ isOpen, onClose, onAddItem }: AddItemModalProps) {
  const [newItem, setNewItem] = useState({
    "Part Number": "",
    Description: "",
    Quantity: "",
    Unit: "",
    Location: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddItem(newItem)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Add New Item</h2>
        <form onSubmit={handleSubmit}>
          {Object.keys(newItem).map((key) => (
            <div key={key} className="mb-4">
              <label className="block text-sm font-bold mb-2" htmlFor={key}>
                {key}
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id={key}
                type={key === "Quantity" ? "number" : "text"}
                value={newItem[key]}
                onChange={(e) => setNewItem({ ...newItem, [key]: e.target.value })}
                required
              />
            </div>
          ))}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2"
            >
              Cancel
            </button>
            <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              Add Item
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

