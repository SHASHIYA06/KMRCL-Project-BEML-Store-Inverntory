"use client"

import { useState } from "react"

interface IssueItemModalProps {
  isOpen: boolean
  onClose: () => void
  onIssueItem: (item: any) => void
  inventory: any[]
}

export default function IssueItemModal({ isOpen, onClose, onIssueItem, inventory }: IssueItemModalProps) {
  const [selectedItem, setSelectedItem] = useState("")
  const [quantity, setQuantity] = useState("")
  const [issuedTo, setIssuedTo] = useState("")
  const [ncrNumber, setNcrNumber] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const item = inventory.find((i) => i["Part Number"] === selectedItem)
    if (item) {
      onIssueItem({
        ...item,
        Quantity: Number.parseInt(quantity),
        IssuedTo: issuedTo,
        NCRNumber: ncrNumber,
        DateIssued: new Date().toISOString(),
      })
      onClose()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Issue Item</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-bold mb-2" htmlFor="item">
              Item
            </label>
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="item"
              value={selectedItem}
              onChange={(e) => setSelectedItem(e.target.value)}
              required
            >
              <option value="">Select an item</option>
              {inventory.map((item) => (
                <option key={item["Part Number"]} value={item["Part Number"]}>
                  {item["Part Number"]} - {item["Description"]}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <label className="block text-sm font-bold mb-2" htmlFor="quantity">
              Quantity
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="quantity"
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-sm font-bold mb-2" htmlFor="issuedTo">
              Issued To
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="issuedTo"
              type="text"
              value={issuedTo}
              onChange={(e) => setIssuedTo(e.target.value)}
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-sm font-bold mb-2" htmlFor="ncrNumber">
              NCR Number
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="ncrNumber"
              type="text"
              value={ncrNumber}
              onChange={(e) => setNcrNumber(e.target.value)}
              required
            />
          </div>
          <div className="flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2"
            >
              Cancel
            </button>
            <button type="submit" className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
              Issue Item
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

