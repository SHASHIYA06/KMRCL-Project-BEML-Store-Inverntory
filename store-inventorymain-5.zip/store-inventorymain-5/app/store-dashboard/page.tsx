"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import AddItemModal from "../../components/AddItemModal";
import IssueItemModal from "../../components/IssueItemModal";
import { DynamicInventoryTable } from "../../components/DynamicInventoryTable";
import { updateProducts } from "../../utils/inventory";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function StoreDashboard() {
  const [inventory, setInventory] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/fetch-inventory");
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      if (!data.inventory) {
        throw new Error("Invalid data structure received");
      }
      setInventory(data.inventory);
    } catch (error) {
      console.error("Error fetching inventory:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredInventory = inventory.filter((item) =>
    Object.values(item)
      .join(" ")
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  const chartData = {
    labels: inventory.map((item) => item.partNumber || item["Part Number"] || "Unknown"),
    datasets: [
      {
        label: "Quantity",
        data: inventory.map((item) => Number(item.quantity || item["Quantity"] || 0)),
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  };

  const handleAddItem = (newItem) => {
    const updatedInventory = [...inventory, newItem];
    setInventory(updatedInventory);
    updateProducts(updatedInventory);
  };

  const handleIssueItem = (issuedItem) => {
    const updatedInventory = inventory.map((item) =>
      item.partNumber === issuedItem.partNumber
        ? { ...item, quantity: Math.max(0, Number(item.quantity) - Number(issuedItem.quantity)) }
        : item
    );
    setInventory(updatedInventory);
    updateProducts(updatedInventory);
  };

  const addRepairedItem = () => {
    alert("Add repaired item functionality to be implemented");
  };

  if (isLoading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Error</h1>
        <p className="text-red-500">An error occurred while fetching the inventory:</p>
        <pre className="bg-gray-100 p-4 mt-4 rounded">{error}</pre>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 fade-in">
      <h1 className="text-3xl font-bold mb-8">Store Dashboard</h1>
      <div className="mb-4">
        <Link href="/" passHref>
          <button className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded transition-all">
            Logout
          </button>
        </Link>
      </div>
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search inventory..."
          className="w-full p-2 border rounded"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <h2 className="text-2xl font-semibold mb-4">Inventory</h2>
      <DynamicInventoryTable data={filteredInventory} />
      <div className="mt-8">
        <h2 className="text-2xl font-semibold mb-4">Inventory Visualization</h2>
        {inventory.length > 0 ? <Bar data={chartData} /> : <p>No data available</p>}
      </div>
      <div className="mt-8 space-x-4">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-all"
          onClick={() => setIsAddModalOpen(true)}
        >
          Add Item
        </button>
        <button
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-all"
          onClick={() => setIsIssueModalOpen(true)}
        >
          Issue Item
        </button>
        <button
          className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded transition-all"
          onClick={addRepairedItem}
        >
          Add Repaired Item
        </button>
      </div>
      <AddItemModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddItem={handleAddItem}
      />
      <IssueItemModal
        isOpen={isIssueModalOpen}
        onClose={() => setIsIssueModalOpen(false)}
        onIssueItem={handleIssueItem}
        inventory={inventory}
      />
    </div>
  );
}

