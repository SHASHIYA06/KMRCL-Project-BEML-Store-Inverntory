import { NextResponse } from "next/server"
import { google } from "googleapis"

export async function GET() {
  try {
    console.log("Starting fetch-inventory API route")

    const credentials = {
      client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      private_key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
    }

    if (!credentials.client_email || !credentials.private_key) {
      throw new Error("Missing Google service account credentials")
    }

    const auth = new google.auth.JWT({
      email: credentials.client_email,
      key: credentials.private_key,
      scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
    })

    const sheets = google.sheets({ version: "v4", auth })

    console.log("Attempting to fetch data from Google Sheets")
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: "1HPuLbh_0ld_eSG2doz0_PLTGi0sGxyBhsrqc8J7p8LU",
      range: "Sheet1!A:E", // Adjust this range according to your sheet structure
    })

    console.log("Data fetched successfully")

    const rows = response.data.values

    if (rows && rows.length) {
      const headers = rows[0]
      const inventory = rows.slice(1).map((row) => {
        return headers.reduce((obj, header, index) => {
          obj[header] = row[index]
          return obj
        }, {})
      })

      console.log("Inventory processed successfully")
      return NextResponse.json({ inventory })
    } else {
      console.log("No data found in the sheet")
      return NextResponse.json({ error: "No data found in the sheet" }, { status: 404 })
    }
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch inventory data",
        details: error.message,
        stack: error.stack,
      },
      { status: 500 },
    )
  }
}

