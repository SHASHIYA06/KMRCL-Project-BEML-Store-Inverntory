"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"

const storePersonnel = [
  { name: "Sanjay Kumar Chaudhary", password: "SanjayKumarChaudhary@4321" },
  { name: "Debtanu Bnarjee", password: "DebtanuBnarjee@4321" },
]

export default function StoreLogin() {
  const [selectedPerson, setSelectedPerson] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const person = storePersonnel.find((p) => p.name === selectedPerson)
    if (person && person.password === password) {
      router.push("/store-dashboard")
    } else {
      alert("Invalid credentials")
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold mb-8">Store Login</h1>
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 fade-in">
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="storePerson">
            Store Personnel
          </label>
          <select
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="storePerson"
            value={selectedPerson}
            onChange={(e) => setSelectedPerson(e.target.value)}
          >
            <option value="">Select store personnel</option>
            {storePersonnel.map((person) => (
              <option key={person.name} value={person.name}>
                {person.name}
              </option>
            ))}
          </select>
        </div>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
            Password
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            id="password"
            type="password"
            placeholder="******************"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div className="flex items-center justify-between">
          <button
            className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition-all hover-scale"
            type="submit"
          >
            Sign In
          </button>
        </div>
      </form>
    </div>
  )
}

