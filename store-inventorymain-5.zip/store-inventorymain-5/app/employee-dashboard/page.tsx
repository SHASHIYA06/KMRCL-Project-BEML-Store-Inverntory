"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Bar } from "react-chartjs-2"
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js"
import { displayAlert } from "../../utils/inventory"

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

export default function EmployeeDashboard() {
  const [spares, setSpares] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchSpares()
    displayAlert()
  }, [])

  const fetchSpares = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch("/api/fetch-inventory")
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      if (data.error) {
        throw new Error(data.error)
      }
      setSpares(data.inventory)
    } catch (error) {
      console.error("Error fetching spares:", error)
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredSpares = spares.filter((spare) =>
    Object.values(spare).some((value) => value.toString().toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const chartData = {
    labels: spares.map((spare) => spare["Part Number"]),
    datasets: [
      {
        label: "Quantity",
        data: spares.map((spare) => Number.parseInt(spare["Quantity"])),
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  }

  const generateReport = () => {
    const report = spares.map((spare) => `${spare["Part Number"]}: ${spare["Quantity"]} ${spare["Unit"]}`).join("\n")
    const blob = new Blob([report], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "inventory_report.txt"
    a.click()
  }

  const requestMaterial = () => {
    alert("Material request functionality to be implemented")
  }

  if (isLoading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>
  }

  if (error) {
    return <div className="container mx-auto px-4 py-8">Error: {error}</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Employee Dashboard</h1>
      <div className="mb-4">
        <Link href="/">
          <button className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded transition-all hover-scale">
            Logout
          </button>
        </Link>
      </div>
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search spares..."
          className="w-full p-2 border rounded"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <h2 className="text-2xl font-semibold mb-4">Spares Details</h2>
      <table className="min-w-full bg-white border border-gray-300">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b">Part Number</th>
            <th className="py-2 px-4 border-b">Description</th>
            <th className="py-2 px-4 border-b">Quantity</th>
            <th className="py-2 px-4 border-b">Unit</th>
            <th className="py-2 px-4 border-b">Location</th>
          </tr>
        </thead>
        <tbody>
          {filteredSpares.map((spare, index) => (
            <tr key={index}>
              <td className="py-2 px-4 border-b">{spare["Part Number"]}</td>
              <td className="py-2 px-4 border-b">{spare["Description"]}</td>
              <td className="py-2 px-4 border-b">{spare["Quantity"]}</td>
              <td className="py-2 px-4 border-b">{spare["Unit"]}</td>
              <td className="py-2 px-4 border-b">{spare["Location"]}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-8">
        <h2 className="text-2xl font-semibold mb-4">Inventory Visualization</h2>
        <Bar data={chartData} />
      </div>
      <div className="mt-8 space-x-4">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-all hover-scale"
          onClick={generateReport}
        >
          Generate Report
        </button>
        <button
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-all hover-scale"
          onClick={requestMaterial}
        >
          Request Material
        </button>
      </div>
    </div>
  )
}

